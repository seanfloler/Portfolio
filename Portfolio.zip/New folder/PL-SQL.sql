--Final Version

Set SERVEROUTPUT on;

-- 1
--Determines if a given number is even or odd
DECLARE
  given_number Integer:=4;
Begin
  if(MOD(given_number,2)=0) then
    dbms_output.put_line('Number is Even');
  else
    dbms_output.put_line('Number is Odd');
  end if;
end;

-- 2
--Determines if a given letter is a vowel or a consonant
DECLARE
      TYPE list IS TABLE OF CHAR;
      n CHAR := 'e';
      a LIST := list('a', 'e', 'i','o','u');
BEGIN
      IF n MEMBER OF a THEN
       dbms_output.put_line(n||' is a vowel.');
      else
       dbms_output.put_line(n||' is a consonant.');
      END IF;
END;
 
 -- 3 Find the circumference given the radius
 DECLARE 
  pi CONSTANT number:= 3.1415;
  radius  Integer := 11;
  diamater Integer;
  circumference number;
 BEGIN
  diamater:=2*radius;
  circumference:= pi*diamater;
  dbms_output.put_line('The circumference of a circle whose radius is '||radius||' is '||circumference);
 end;
 
  -- 4 Weak password encryption
 DECLARE 
  pass varchar2(10):='password';
  replacer varchar2(10):='aeioustb';
  replace_with varchar2(10) :='@)!(*+_~';
  
 BEGIN
  pass:=TRANSLATE(pass, replacer, replace_with);
    dbms_output.put_line('Password: '||pass);
  dbms_output.put_line('Password length: '||length(pass));
 end;
 
 -- 5 Variable arithmatic
 DECLARE 
  v1 Number:=5;
  v2 Number:=51;
  low_ Number;
  high_ Number;
  result_ Number;
 BEGIN
  if v1 > v2 then
    low_:=v2;
    high_:=v1;
  elsif v2 > v1 then
    low_:=v1;
    high_:=v2;
  end if;
  
  if(v1=v2) then
   dbms_output.put_line('Please give the program 2 different numbers');
  else
   --Addition
     result_:= v1+v2;
     dbms_output.put_line(v1||' + '||v2||' = '||result_);
  
   --Subtraction
     result_:= high_-low_;
     dbms_output.put_line(high_||' - '||low_||' = '||result_);
  
  --Multiplication
     result_:= v1*v2;
     dbms_output.put_line(v1||' * '||v2||' = '||result_);
  
   --Division
     result_:=high_/low_;
     dbms_output.put_line(high_||' / '||low_||' = '||result_); 
  end if;
 end;
 

